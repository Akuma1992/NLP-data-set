# Lugbara MT evaluation pipeline

Computes every number and figure in Chapter 4 from your own output files.

    pip install sacrebleu nltk pandas matplotlib
    python -c "import nltk; nltk.download('wordnet'); nltk.download('omw-1.4')"
    python lugbara_eval.py --manifest manifest.json --out results/

## Input files
* `test.csv` - the held-out test split: `id, domain, english, lugbara` (one row per pair).
* System outputs - plain text, **one line per test row, same order**. Direction tags (`<2en>`, `<2lg>`) are stripped automatically.
* `polysemy_test.csv` - `id, direction (en2lg|lg2en), source, reference, target_word, gold_sense`.
* `sense_lexicon.csv` - `word, sense_id, gloss, frequency, english_renderings, lugbara_renderings`
  (renderings separated by `|`; prefix `re:` for a regular expression).
* Optional: `manual_labels_csv` (`id, system, direction, predicted_sense`) overrides the automatic
  sense classifier for items you adjudicate by hand (recommended for every row the script marks
  `unresolved` or `ambiguous` in `results/esm_detail.csv`).
* Optional: Hugging Face `trainer_state.json` files, `grid_search.csv` (`model, direction, lr, batch_size, val_bleu`),
  `latency.csv` (`system, ms_per_sentence`).

## What is computed
| Metric | Implementation |
|---|---|
| BLEU | sacreBLEU corpus BLEU, 13a tokenisation (signature written to `meta.json`) |
| TER | sacreBLEU TER |
| METEOR | NLTK `meteor_score`, sentence average; exact + stem + WordNet for English output, exact match only for Lugbara output |
| ESM | share of polysemy-test outputs whose rendering matches the gold sense in the lexicon (ambiguous/unresolved counted as misses; lenient variant also reported) |
| AIR | output level: share of glottal-initial reference tokens reproduced with the apostrophe intact (vs. dropped or split); tokenizer level if tokenizers are supplied |
| CIs / significance | 1,000 bootstrap resamples; paired bootstrap (Koehn, 2004), two-sided p |

Outputs: `metrics_overall.csv`, `metrics_by_domain.csv`, `significance.csv`, `esm_summary.csv`,
`esm_detail.csv`, `meta.json`, `summary.md`, `figures/*.png` (300 dpi).
