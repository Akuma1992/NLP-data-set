"""Fig 2.x: position of Lugbara within Moru-Madi (Central Sudanic), following Glottolog."""
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import figstyle as fs

fs.apply()
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "img", "")
os.makedirs(OUT, exist_ok=True)

# node: (x, y, label, highlight)
N = {
    "cs": (0.50, 5.0, "Central Sudanic", False),
    "mm": (0.50, 4.0, "Moru-Madi", False),
    "cmm": (0.30, 3.0, "Central\nMoru-Madi", False),
    "smm": (0.72, 3.0, "Southern\nMoru-Madi", False),
    "moru": (0.93, 3.0, "Moru", False),
    "lgc": (0.16, 2.0, "Lugbaric", False),
    "avc": (0.49, 2.0, "Avokayic", False),
    "lgg": (0.05, 1.0, "Lugbara\n(ISO lgg)", True),
    "arg": (0.27, 1.0, "Aringa\n(ISO luc)", False),
    "avo": (0.49, 1.0, "Avokaya, Logo,\nKeliko", False),
    "madi": (0.72, 1.0, "Ma'di, Southern\nMa'di, Olu'bo", False),
}
E = [("cs", "mm"), ("mm", "cmm"), ("mm", "smm"), ("mm", "moru"), ("cmm", "lgc"), ("cmm", "avc"),
     ("lgc", "lgg"), ("lgc", "arg"), ("avc", "avo"), ("smm", "madi")]


def main():
    fig, ax = plt.subplots(figsize=(6.0, 3.6))
    W, H = 0.185, 0.56
    for a, b in E:
        xa, ya, _, _ = N[a]; xb, yb, _, _ = N[b]
        ym = (ya + yb) / 2
        ax.plot([xa, xa, xb, xb], [ya - H / 2, ym, ym, yb + H / 2], color=fs.AXIS, lw=1.0, zorder=1)
    for k, (x, y, lab, hi) in N.items():
        w = W if "\n" not in lab else W + 0.02
        ax.add_patch(FancyBboxPatch((x - w / 2, y - H / 2), w, H, boxstyle="round,pad=0,rounding_size=0.02",
                                    fc=fs.SERIES[0] if hi else "#f4f3ef", ec=fs.SERIES[0] if hi else fs.AXIS, lw=0.9, zorder=2))
        ax.text(x, y, lab, ha="center", va="center", fontsize=8.4, color="white" if hi else fs.INK,
                fontweight="semibold" if hi else "normal", linespacing=1.15, zorder=3)
    ax.set_xlim(-0.07, 1.04)
    ax.set_ylim(0.55, 5.4)
    ax.axis("off")
    fig.tight_layout()
    fig.savefig(OUT + "ch2_lugbara_family.png", bbox_inches="tight", pad_inches=0.05)
    print("wrote ch2_lugbara_family.png")


if __name__ == "__main__":
    main()
