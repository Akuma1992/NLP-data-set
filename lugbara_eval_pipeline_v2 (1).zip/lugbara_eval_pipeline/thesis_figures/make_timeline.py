"""Fig 2.1: milestones in machine translation, as cited in Chapter Two.
Every event and year is taken from a source cited in Section 2.1, 2.4 or 2.6."""
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import matplotlib.pyplot as plt
import figstyle as fs

fs.apply()
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "img", "")
os.makedirs(OUT, exist_ok=True)

# (year, label, lane) lane 0 = MT paradigms (above axis), lane 1 = models & African resources (below)
EV = [
    (1954, "Georgetown–IBM\ndemonstration", 0),
    (1966, "ALPAC report", 0),
    (1993, "IBM statistical\nmodels", 0),
    (2003, "Phrase-based\nSMT", 0),
    (2006, "Online statistical\nMT (Google)", 0),
    (2014, "Sequence-to-sequence\nNMT", 0),
    (2015, "Attention", 0),
    (2017, "Transformer", 0),
    (2018, "ULMFiT", 1),
    (2019, "BERT / mBERT", 1),
    (2020, "XLM-R;\nMasakhane", 1),
    (2021, "mT5", 1),
    (2022, "SALT (incl. Lugbara);\nMAFAND-MT", 1),
    (2024, "NLLB-200", 1),
]


def main():
    n = len(EV)
    fig, ax = plt.subplots(figsize=(5.6, 4.2))
    ys = [n - 1 - i for i in range(n)]
    ax.plot([0, 0], [-0.6, n - 0.4], color=fs.AXIS, lw=1.2, zorder=1)
    for (yr, lab, lane), y in zip(EV, ys):
        col = fs.SERIES[0] if lane == 0 else fs.SERIES[1]
        ax.scatter([0], [y], s=30, color=col, edgecolor="white", linewidth=1.3, zorder=3)
        side = -1 if lane == 0 else 1
        ax.plot([0, side * 0.18], [y, y], color=col, lw=0.9, zorder=2)
        ax.text(side * 0.24, y, f"{yr}  " + lab.replace("\n", " ") if side > 0 else lab.replace("\n", " ") + f"  {yr}",
                ha="left" if side > 0 else "right", va="center", fontsize=8.2, color=fs.INK)
    ax.text(-0.24, n - 0.05, "Translation paradigms", ha="right", va="bottom", fontsize=8.4, color=fs.SERIES[0], fontweight="semibold")
    ax.text(0.24, n - 0.05, "Pre-trained models and resources", ha="left", va="bottom", fontsize=8.4, color=fs.SERIES[1], fontweight="semibold")
    ax.set_xlim(-2.75, 3.1)
    ax.set_ylim(-0.8, n + 0.5)
    ax.axis("off")
    fig.tight_layout()
    fig.savefig(OUT + "ch2_mt_timeline.png", bbox_inches="tight", pad_inches=0.05)
    print("wrote ch2_mt_timeline.png")


if __name__ == "__main__":
    main()
