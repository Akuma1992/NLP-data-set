"""Figures whose data are already stated in the thesis text (Chapters 3-4).
Every value plotted here appears verbatim in a table or sentence of the thesis."""
import os
import sys
import textwrap
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import figstyle as fs

fs.apply()
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "img", "")
os.makedirs(OUT, exist_ok=True)


def save(fig, name):
    fig.savefig(OUT + name)
    plt.close(fig)
    print("wrote", name)


# ------------------------------------------------------------ Fig 3.1 process flow
def process_flow():
    cols = [
        ("Corpus construction\n(§3.2)", ["Domain sentence collection: Agriculture, Tourism, Religion",
                                          "Human translation by 60 Lugbara–English linguists",
                                          "Cross-verification: accuracy, completeness, grammar, fluency",
                                          "Cleaning and tokenisation (Moses; Lugbara rule-based)",
                                          "Stratified 70/15/15 split"]),
        ("Polysemy resource\n(§3.3)", ["75 polysemous target words",
                                        "Sense inventory with frequencies",
                                        "Contextual trigger database",
                                        "500 sense-annotated sentences (κ = 0.89)"]),
        ("Fine-tuning\n(§3.4.1–3.4.2)", ["Fine-tune mBERT, XLM-R, mT5, ULMFiT",
                                    "Both directions: En→Lg and Lg→En",
                                    "Early stopping on validation loss"]),
        ("Optimisation\n(§3.4.3)", ["Grid search: learning rate, batch size",
                                     "Tuned XLM-R (En→Lg)",
                                     "Tuned mT5 (Lg→En)"]),
        ("Evaluation\n(§3.5)", ["BLEU, TER and F1 on the test split",
                                 "BLEU by domain",
                                 "Sense-accuracy probes",
                                 "Manual error analysis"]),
    ]
    W, H = 6.7, 4.0
    fig = plt.figure(figsize=(W, H))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, W)
    ax.set_ylim(0, H)
    ax.axis("off")
    n = len(cols)
    gap = 0.14
    cw = (W - gap * (n + 1)) / n
    head_h, step_h, vgap = 0.52, 0.5, 0.13
    top = H - 0.08
    for i, (head, steps) in enumerate(cols):
        x = gap + i * (cw + gap)
        ax.add_patch(FancyBboxPatch((x, top - head_h), cw, head_h, boxstyle="round,pad=0,rounding_size=0.06",
                                    fc=fs.SEQ_BLUE[7], ec="none"))
        ax.text(x + cw / 2, top - head_h / 2, head, ha="center", va="center", color="white",
                fontsize=7.2, fontweight="semibold", linespacing=1.15)
        y = top - head_h - 0.2
        for j, s in enumerate(steps):
            ax.add_patch(FancyBboxPatch((x, y - step_h), cw, step_h, boxstyle="round,pad=0,rounding_size=0.05",
                                        fc="#f4f3ef", ec=fs.AXIS, lw=0.7))
            ax.text(x + cw / 2, y - step_h / 2, "\n".join(textwrap.wrap(s, 21)), ha="center", va="center",
                    fontsize=6.3, color=fs.INK, linespacing=1.12)
            if j < len(steps) - 1:
                ax.add_patch(FancyArrowPatch((x + cw / 2, y - step_h), (x + cw / 2, y - step_h - vgap),
                                             arrowstyle="-|>", mutation_scale=7, color=fs.INK2, lw=0.8))
            y -= step_h + vgap
        if i < n - 1:
            ax.add_patch(FancyArrowPatch((x + cw, top - head_h / 2), (x + cw + gap, top - head_h / 2),
                                         arrowstyle="-|>", mutation_scale=8, color=fs.INK2, lw=1.0))
    save(fig, "ch3_process_flow.png")


# ------------------------------------------------------------ Fig 3.2 corpus split
def corpus_split():
    doms = ["Agriculture", "Tourism", "Religion"]
    data = {"Train": [3623, 3620, 3624], "Validation": [776, 776, 777], "Test": [776, 776, 776]}
    fig, ax = plt.subplots(figsize=(6.0, 2.6))
    w = 0.24
    for di, d in enumerate(doms):
        xs = np.arange(3) + (di - 1) * (w + 0.02)
        bars = ax.bar(xs, [data[k][di] for k in data], width=w, color=fs.SERIES[di], label=d, zorder=2)
        fs.value_labels(ax, bars, fmt="{:,.0f}", size=6.8)
    ax.set_xticks(range(3))
    ax.set_xticklabels(list(data))
    ax.set_ylabel("Sentence pairs")
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:,.0f}"))
    ax.grid(axis="x", visible=False)
    ax.set_ylim(0, 4200)
    ax.legend(ncol=3, loc="upper right")
    save(fig, "ch3_corpus_split.png")


# ------------------------------------------------------------ Ch4 corpus-analysis bars
def simple_bars(cats, vals, ylabel, name, xlabel=None, fmt="{:.0f}%"):
    fig, ax = plt.subplots(figsize=(5.6, 2.5))
    bars = ax.bar(cats, vals, width=0.5, color=fs.SERIES[0], zorder=2)
    fs.value_labels(ax, bars, fmt=fmt, size=7.5)
    ax.set_ylabel(ylabel)
    if xlabel:
        ax.set_xlabel(xlabel)
    ax.grid(axis="x", visible=False)
    ax.set_ylim(0, max(vals) * 1.18)
    save(fig, name)


def polysemy_by_verb():
    verbs = ["'Bá", "Aga'", "Ede'", "Ndre'", "Fé", "Eri'"]
    acc = {"mBERT": [52, 38, 40, 42, 48, 39], "XLM-R": [65, 52, 49, 55, 61, 53], "mT5": [68, 55, 53, 58, 64, 56]}
    fig, ax = plt.subplots(figsize=(6.2, 2.6))
    w = 0.24
    for mi, (m, v) in enumerate(acc.items()):
        xs = np.arange(len(verbs)) + (mi - 1) * (w + 0.02)
        bars = ax.bar(xs, v, width=w, color=fs.SERIES[mi], label=m, zorder=2)
        fs.value_labels(ax, bars, fmt="{:.0f}", size=6.3)
    ax.set_xticks(range(len(verbs)))
    ax.set_xticklabels(verbs, style="italic")
    ax.set_ylabel("Sense accuracy (%)")
    ax.set_ylim(0, 80)
    ax.grid(axis="x", visible=False)
    ax.legend(ncol=3, loc="upper right")
    save(fig, "ch4_polysemy_by_verb.png")


def sense_distribution():
    """100% stacked bars of the sense-frequency inventory (Table 3.3)."""
    words = ["'Bá", "Aga'", "Ede'", "Ndre'", "Fé", "Eri'"]
    senses = {"'Bá": [("breast/chest", 45), ("putting/dressing", 35), ("reach/achieve", 20)],
              "Aga'": [("more/additional", 40), ("conquer/defeat", 30), ("middle/centre", 20), ("absorbed", 10)],
              "Ede'": [("fall/descend", 50), ("decrease/diminish", 30), ("fail/collapse", 20)],
              "Ndre'": [("see/notice", 40), ("understand", 35), ("visit/meet", 25)],
              "Fé": [("give/provide", 50), ("allow/permit", 30), ("cause/make happen", 20)],
              "Eri'": [("hear/listen", 40), ("obey/follow", 35), ("understand/grasp", 25)]}
    ramp = [fs.SEQ_BLUE[10], fs.SEQ_BLUE[7], fs.SEQ_BLUE[4], fs.SEQ_BLUE[2]]
    fig, ax = plt.subplots(figsize=(6.4, 2.9))
    y = np.arange(len(words))[::-1]
    for wi, wd in enumerate(words):
        left = 0
        for si, (lab, f) in enumerate(senses[wd]):
            ax.barh(y[wi], f - 0.6, left=left + 0.3, height=0.62, color=ramp[si], zorder=2,
                    label=["Most frequent sense", "Second sense", "Third sense", "Fourth sense"][si] if wi == 1 else None)
            txt = f"{lab} {f}%"
            col = "white" if si < 2 else fs.INK
            if f <= 20:
                txt = f"{lab.split('/')[0]} {f}%"
            ax.text(left + f / 2, y[wi], txt, ha="center", va="center", fontsize=6.0 if f > 10 else 4.7, color=col)
            left += f
    ax.set_yticks(y)
    ax.set_yticklabels(words, style="italic")
    ax.set_xlim(0, 100)
    ax.set_xlabel("Share of occurrences in the corpus (%)")
    ax.grid(False)
    ax.legend(ncol=4, loc="lower center", bbox_to_anchor=(0.5, -0.42), fontsize=7.2)
    save(fig, "ch4_sense_distribution.png")


def confused_pairs():
    pairs = ["aga': more ↔ conquer\n(mBERT)", "fé: give ↔ cause/allow", "ede': fall ↔ decrease", "ndre': see ↔ understand"]
    vals = [78, 65, 55, 42]
    fig, ax = plt.subplots(figsize=(5.8, 2.2))
    y = np.arange(len(pairs))[::-1]
    bars = ax.barh(y, vals, height=0.55, color=fs.SERIES[0], zorder=2)
    fs.hvalue_labels(ax, bars, fmt="{:.0f}%")
    ax.set_yticks(y)
    ax.set_yticklabels(pairs, fontsize=7.5)
    ax.set_xlim(0, 100)
    ax.set_xlabel("Share of occurrences confused (%)")
    ax.grid(axis="y", visible=False)
    save(fig, "ch4_confused_pairs.png")


if __name__ == "__main__":
    process_flow()
    corpus_split()
    simple_bars(["Natural\nequivalent", "Paraphrase /\nexplanation", "Loanword", "Calque"], [52, 28, 15, 5],
                "Share of lexical items (%)", "ch4_translation_strategies.png")
    simple_bars(["Modern institutions\n& technology", "Food & culture", "Titles &\nprofessions", "Other"], [35, 25, 20, 20],
                "Share of loanwords (%)", "ch4_loanword_categories.png")
    simple_bars(["Particle ni", "Phrase eri ovu", "Existential ci", "Other"], [42, 33, 15, 10],
                "Share of 'to be' renderings (%)", "ch4_copula.png")
    polysemy_by_verb()
    sense_distribution()
    confused_pairs()


def error_types():
    simple_bars(["Morphological", "Lexical\nomission", "Word order", "Semantic", "Other"], [45, 25, 15, 10, 5],
                "Share of annotated errors (%)", "ch4_error_types.png")


if __name__ == "__main__":
    error_types()


# ------------------------------------------------------------ reported MT results (original Chapter 4 tables)
EN = {"mBERT": (12.34, 68.91, 0.62), "XLM-R": (15.67, 63.45, 0.67), "mT5": (18.92, 59.83, 0.71),
      "ULMFiT": (10.15, 72.30, 0.58)}
LG = {"mBERT": (14.57, 65.23, 0.65), "XLM-R": (18.92, 60.10, 0.70), "mT5": (21.05, 56.89, 0.74),
      "ULMFiT": (11.89, 70.45, 0.61)}
TUNED = {"en": ("XLM-R (tuned)", (22.18, 55.12, 0.76)), "lg": ("mT5 (tuned)", (25.41, 52.67, 0.79))}


def bleu_models():
    fig, axes = plt.subplots(1, 2, figsize=(6.6, 2.6), sharex=True)
    for ax, (key, base, title) in zip(axes, [("en", EN, "English → Lugbara"), ("lg", LG, "Lugbara → English")]):
        names = list(base) + [TUNED[key][0]]
        vals = [base[m][0] for m in base] + [TUNED[key][1][0]]
        y = np.arange(len(names))[::-1]
        cols = [fs.DEEMPH] * len(base) + [fs.SERIES[0]]
        bars = ax.barh(y, vals, height=0.6, color=cols, zorder=2)
        fs.hvalue_labels(ax, bars, fmt="{:.2f}", size=7)
        ax.set_yticks(y)
        ax.set_yticklabels(names)
        ax.set_title(title)
        ax.set_xlabel("BLEU")
        ax.set_xlim(0, 30)
        ax.grid(axis="y", visible=False)
    fig.tight_layout()
    save(fig, "ch4_bleu_models.png")


def ter_f1_models():
    models = ["mBERT", "XLM-R", "mT5", "ULMFiT", "Tuned"]
    fig, axes = plt.subplots(1, 2, figsize=(6.6, 2.6))
    w = 0.34
    for ai, (ax, idx, title, fmt, lim) in enumerate(zip(axes, [1, 2], ["TER (↓ lower is better)", "F1-score (↑ higher is better)"],
                                                      ["{:.1f}", "{:.2f}"], [85, 0.95])):
        for di, (key, base, lab) in enumerate([("en", EN, "English → Lugbara"), ("lg", LG, "Lugbara → English")]):
            vals = [base[m][idx] for m in models[:4]] + [TUNED[key][1][idx]]
            xs = np.arange(len(models)) + (di - 0.5) * (w + 0.03)
            bars = ax.bar(xs, vals, width=w, color=fs.SERIES[di], label=lab, zorder=2)
            fs.value_labels(ax, bars, fmt=fmt, size=5.8)
        ax.set_xticks(range(len(models)))
        ax.set_xticklabels(models, fontsize=7.5)
        ax.set_title(title, fontsize=9)
        ax.set_ylim(0, lim)
        ax.grid(axis="x", visible=False)
    h, l = axes[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=2, bbox_to_anchor=(0.5, -0.04))
    fig.tight_layout(rect=(0, 0.07, 1, 1))
    save(fig, "ch4_ter_f1_models.png")


def tuning_gain():
    rows = [("XLM-R, En→Lg", EN["XLM-R"], TUNED["en"][1]), ("mT5, Lg→En", LG["mT5"], TUNED["lg"][1])]
    fig, axes = plt.subplots(1, 3, figsize=(6.6, 1.9), sharey=True)
    for ax, idx, title, fmt in zip(axes, [0, 1, 2], ["BLEU (↑)", "TER (↓)", "F1 (↑)"], ["{:.2f}", "{:.2f}", "{:.2f}"]):
        for yi, (lab, b, t) in enumerate(rows):
            y = len(rows) - 1 - yi
            ax.plot([b[idx], t[idx]], [y, y], color=fs.AXIS, lw=2, zorder=1)
            ax.scatter([b[idx]], [y], s=42, color=fs.DEEMPH, edgecolor="white", linewidth=1.5, zorder=2, label="Baseline" if yi == 0 else None)
            ax.scatter([t[idx]], [y], s=42, color=fs.SERIES[0], edgecolor="white", linewidth=1.5, zorder=3, label="Tuned" if yi == 0 else None)
            for v in (b[idx], t[idx]):
                ax.annotate(fmt.format(v), (v, y), xytext=(0, 7), textcoords="offset points", ha="center", fontsize=6.5, color=fs.INK2)
        ax.set_title(title, fontsize=8.5)
        ax.set_yticks(range(len(rows)))
        ax.set_yticklabels([r[0] for r in rows][::-1], fontsize=7.5)
        ax.set_ylim(-0.6, len(rows) - 0.3)
        ax.margins(x=0.25)
        ax.grid(axis="y", visible=False)
        ax.tick_params(axis="x", labelsize=7)
    h, l = axes[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=2, bbox_to_anchor=(0.5, -0.1), fontsize=7.5)
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    save(fig, "ch4_tuning_gain.png")


def direction_gap():
    models = ["mBERT", "XLM-R", "mT5", "ULMFiT"]
    names = models + ["Tuned (XLM-R / mT5)"]
    en = [EN[m][0] for m in models] + [TUNED["en"][1][0]]
    lg = [LG[m][0] for m in models] + [TUNED["lg"][1][0]]
    fig, ax = plt.subplots(figsize=(6.0, 2.4))
    y = np.arange(len(names))[::-1]
    for yi, a, b in zip(y, en, lg):
        ax.plot([a, b], [yi, yi], color=fs.AXIS, lw=2, zorder=1)
        ax.annotate(f"+{b - a:.2f}", (b, yi), xytext=(8, 0), textcoords="offset points", va="center", fontsize=7, color=fs.INK2)
    ax.scatter(en, y, s=42, color=fs.SERIES[0], edgecolor="white", linewidth=1.5, zorder=3, label="English → Lugbara")
    ax.scatter(lg, y, s=42, color=fs.SERIES[1], edgecolor="white", linewidth=1.5, zorder=3, label="Lugbara → English")
    ax.set_yticks(y)
    ax.set_yticklabels(names)
    ax.set_xlabel("BLEU")
    ax.set_xlim(8, 29)
    ax.grid(axis="y", visible=False)
    ax.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=2, fontsize=7.5)
    save(fig, "ch4_direction_gap.png")


def domain_bleu():
    cats = ["Tourism", "Agriculture", "Religion", "All domains"]
    vals = [24.5, 22.8, 19.7, 21.2]
    fig, ax = plt.subplots(figsize=(5.4, 2.4))
    bars = ax.bar(cats, vals, width=0.5, color=[fs.SERIES[0]] * 3 + [fs.DEEMPH], zorder=2)
    fs.value_labels(ax, bars, fmt="{:.1f}", size=7.5)
    ax.set_ylabel("BLEU")
    ax.set_ylim(0, 29)
    ax.grid(axis="x", visible=False)
    save(fig, "ch4_domain_bleu.png")


if __name__ == "__main__":
    bleu_models()
    ter_f1_models()
    tuning_gain()
    direction_gap()
    domain_bleu()


def _box(ax, x, y, w, h, text, fc="#f4f3ef", ec=None, bold=False, fs_=6.8, color=None):
    ax.add_patch(FancyBboxPatch((x - w / 2, y - h / 2), w, h, boxstyle="round,pad=0,rounding_size=0.05",
                                fc=fc, ec=ec or fs.AXIS, lw=0.8))
    ax.text(x, y, text, ha="center", va="center", fontsize=fs_, color=color or fs.INK,
            fontweight="semibold" if bold else "normal", linespacing=1.2)


def _arrow(ax, p, q, rad=0.0):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=8, color=fs.INK2, lw=0.9,
                                 connectionstyle=f"arc3,rad={rad}"))


def ensemble_pipeline():
    fig = plt.figure(figsize=(6.0, 4.6))
    ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 6); ax.set_ylim(0, 4.6); ax.axis("off")
    blue = fs.SEQ_BLUE[0]
    _box(ax, 3, 4.3, 2.6, 0.42, "Source sentence + direction tag\n<2en> / <2lg>", fc=blue)
    _box(ax, 3, 3.62, 2.6, 0.42, "Apostrophe-preserving preprocessing (§A.5)")
    _box(ax, 1.4, 2.85, 2.1, 0.42, "XLM-R\n(fine-tuned, both directions)")
    _box(ax, 4.6, 2.85, 2.1, 0.42, "mT5\n(fine-tuned, both directions)")
    _box(ax, 1.4, 2.15, 2.1, 0.42, "Top-5 candidates\n(beam search)")
    _box(ax, 4.6, 2.15, 2.1, 0.42, "Top-5 candidates\n(beam search)")
    _box(ax, 3.4, 1.35, 3.2, 0.5, "Lexicon-scored re-ranking (§A.4)\nscore(c) = log P(c) + α·match(c) − β·conflict(c)", fc=blue, bold=True, fs_=6.6)
    _box(ax, 0.75, 1.35, 1.2, 0.5, "Sense lexicon +\ntrigger database\n(§3.3)", fc="#fbf3e2", fs_=6.3)
    _box(ax, 3.4, 0.68, 2.6, 0.42, "Apostrophe restoration")
    _box(ax, 3.4, 0.14, 2.6, 0.24, "Selected translation", fc=blue, bold=True)
    _arrow(ax, (3, 4.09), (3, 3.83))
    _arrow(ax, (2.6, 3.41), (1.6, 3.06)); _arrow(ax, (3.4, 3.41), (4.4, 3.06))
    _arrow(ax, (1.4, 2.64), (1.4, 2.36)); _arrow(ax, (4.6, 2.64), (4.6, 2.36))
    _arrow(ax, (1.8, 1.94), (2.7, 1.6)); _arrow(ax, (4.4, 1.94), (4.0, 1.6))
    _arrow(ax, (1.35, 1.35), (1.8, 1.35))
    _arrow(ax, (3.4, 1.1), (3.4, 0.89)); _arrow(ax, (3.4, 0.47), (3.4, 0.26))
    save(fig, "appA_pipeline.png")


def ablation_design():
    fig = plt.figure(figsize=(6.4, 2.7))
    ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 6.4); ax.set_ylim(0, 2.7); ax.axis("off")
    cols = [(1.0, "Condition A", "Best single model\n\n• Tuned XLM-R (En→Lg)\n  / tuned mT5 (Lg→En)\n• No lexicon intervention"),
            (3.2, "Condition B", "Single-model lexicon-\nbiased decoding\n\n• Condition A model\n• Lexicon match/conflict\n  terms bias decoding"),
            (5.4, "Condition C", "All-through ensemble\n\n• XLM-R + mT5, direction-tagged\n• Lexicon-scored re-ranking\n• + lightweight fallback mode")]
    for x, h, t in cols:
        ax.text(x, 2.55, h, ha="center", va="center", fontsize=8, fontweight="semibold", color=fs.INK)
        _box(ax, x, 1.75, 1.85, 1.2, t, fs_=6.5)
        _arrow(ax, (x, 1.15), (x, 0.82))
    _arrow(ax, (1.95, 1.75), (2.25, 1.75)); _arrow(ax, (4.15, 1.75), (4.45, 1.75))
    _box(ax, 3.2, 0.45, 6.0, 0.7, "Shared evaluation on the test split, both directions: BLEU · TER · METEOR · ESM · AIR\n"
         "95% bootstrap confidence intervals; paired bootstrap tests for A vs. B, B vs. C and C vs. fallback", fc="#fafaf8", fs_=6.6)
    save(fig, "appA_ablation.png")


if __name__ == "__main__":
    ensemble_pipeline()
    ablation_design()


def conceptual_framework():
    fig = plt.figure(figsize=(6.6, 3.9))
    ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 6.6); ax.set_ylim(0, 3.9); ax.axis("off")
    head = dict(fontsize=7.6, fontweight="semibold", color=fs.INK)
    ax.text(1.05, 3.72, "Independent variables", ha="center", **head)
    ax.text(3.3, 3.72, "Moderating variables", ha="center", **head)
    ax.text(5.55, 3.72, "Dependent variables", ha="center", **head)
    iv = [(3.05, "Parallel corpus\n• 15,524 verified pairs\n• Agriculture, Tourism, Religion"),
          (1.95, "Model architecture\n• mBERT, XLM-R\n• mT5, ULMFiT"),
          (0.85, "Optimisation\n• Learning rate\n• Batch size")]
    for y, t in iv:
        _box(ax, 1.05, y, 1.9, 0.85, t, fc=fs.SEQ_BLUE[0], fs_=6.5)
    _box(ax, 3.3, 2.3, 1.85, 1.75, "Linguistic properties\nof Lugbara\n\n• Particle-based constructions\n  (ni, eri ovu)\n• Tone and glottal spellings\n• Polysemy and sense skew\n• Direction of translation", fc="#fbf3e2", fs_=6.4)
    _box(ax, 3.3, 0.72, 1.85, 0.62, "Sense lexicon and triggers\n(proposed for future use)", fc="#f4f3ef", fs_=6.3)
    dv = [(3.05, "Translation quality\n• BLEU, TER, F1\n• by domain"),
          (1.95, "Sense accuracy\n• on polysemous words"),
          (0.85, "Error profile\n• morphological, omission,\n  order, semantic")]
    for y, t in dv:
        _box(ax, 5.55, y, 1.9, 0.85, t, fc=fs.SEQ_BLUE[0], fs_=6.5)
    for y, _ in iv:
        _arrow(ax, (2.0, y), (2.37, 2.3 + (y - 1.95) * 0.35))
    for y, _ in dv:
        _arrow(ax, (4.23, 2.3 + (y - 1.95) * 0.35), (4.6, y))
    ax.add_patch(FancyArrowPatch((3.3, 1.03), (3.3, 1.42), arrowstyle="-|>", mutation_scale=8, color=fs.MUTED, lw=0.9, linestyle=(0, (3, 2))))
    save(fig, "ch2_conceptual_framework.png")


if __name__ == "__main__":
    conceptual_framework()
