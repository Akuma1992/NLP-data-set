"""Detailed secondary analyses of the results reported in the thesis.
Every input number below is copied from a table or figure already in the thesis;
everything else is computed here and written to build/analysis.json."""
import json, math, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
from matplotlib.patches import Rectangle
import figstyle as fs
fs.apply()
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "img", "")
os.makedirs(OUT, exist_ok=True)
A = {}

WORDS = ["'Bá", "Aga'", "Ede'", "Ndre'", "Fé", "Eri'"]
SENSES = {"'Bá": [("breast/chest", 45), ("putting/dressing", 35), ("reach/achieve", 20)],
          "Aga'": [("more/additional", 40), ("conquer/defeat", 30), ("middle/centre", 20), ("absorbed", 10)],
          "Ede'": [("fall/descend", 50), ("decrease/diminish", 30), ("fail/collapse", 20)],
          "Ndre'": [("see/notice", 40), ("understand/comprehend", 35), ("visit/meet", 25)],
          "Fé": [("give/provide", 50), ("allow/permit", 30), ("cause/make happen", 20)],
          "Eri'": [("hear/listen", 40), ("obey/follow", 35), ("understand/grasp", 25)]}
ACC = {"mBERT": [52, 38, 40, 42, 48, 39], "XLM-R": [65, 52, 49, 55, 61, 53], "mT5": [68, 55, 53, 58, 64, 56]}
MODELS = list(ACC)


def save(fig, name):
    fig.savefig(OUT + name); plt.close(fig); print("wrote", name)


# ---------------- 1. lift over majority-sense baseline
maj = {w: SENSES[w][0][1] for w in WORDS}
lift = {m: [a - maj[w] for a, w in zip(ACC[m], WORDS)] for m in MODELS}
A["majority_mean"] = round(float(np.mean(list(maj.values()))), 1)
A["lift"] = lift
A["lift_mean"] = {m: round(float(np.mean(v)), 1) for m, v in lift.items()}
A["lift_below_or_at_zero"] = {m: int(sum(x <= 0 for x in v)) for m, v in lift.items()}
cmap = LinearSegmentedColormap.from_list("div", ["#d03b3b", "#f0efec", "#2a78d6"])
M = np.array([lift[m] for m in MODELS]).T
fig, ax = plt.subplots(figsize=(4.6, 3.0))
im = ax.imshow(M, cmap=cmap, norm=TwoSlopeNorm(0, -25, 25), aspect="auto")
for (i, j), v in np.ndenumerate(M):
    ax.text(j, i, f"{v:+d}", ha="center", va="center", fontsize=8.5, color="white" if abs(v) > 14 else fs.INK)
ax.set_xticks(range(3)); ax.set_xticklabels(MODELS)
ax.set_yticks(range(6)); ax.set_yticklabels(WORDS, style="italic")
ax.grid(False)
for s in ax.spines.values(): s.set_visible(False)
cb = fig.colorbar(im, ax=ax, fraction=0.05, pad=0.03); cb.set_label("Percentage points above majority-sense rate", fontsize=7.5)
cb.ax.tick_params(labelsize=7); cb.outline.set_visible(False)
save(fig, "ch4_lift_heatmap.png")

# ---------------- 2. sense entropy vs accuracy
ent = {w: -sum((p / 100) * math.log2(p / 100) for _, p in SENSES[w]) for w in WORDS}
A["entropy"] = {w: round(e, 3) for w, e in ent.items()}
A["entropy_mean"] = round(float(np.mean(list(ent.values()))), 4)
A["n_senses"] = {w: len(SENSES[w]) for w in WORDS}
A["spearman_entropy_acc"] = {m: [round(float(x), 4) for x in stats.spearmanr([ent[w] for w in WORDS], ACC[m])] for m in MODELS}
A["spearman_majority_acc"] = {m: [round(float(x), 4) for x in stats.spearmanr([maj[w] for w in WORDS], ACC[m])] for m in MODELS}
# rank agreement of word difficulty across models (Kendall's W)
R = np.array([stats.rankdata(ACC[m]) for m in MODELS])
k, n = R.shape
S = ((R.sum(0) - k * (n + 1) / 2) ** 2).sum()
A["kendall_W_word_difficulty"] = round(float(12 * S / (k ** 2 * (n ** 3 - n))), 3)

# ---------------- 3. case-study sense-choice matrices
CASES = [("Aga'", "conquer/defeat", {"mBERT": ("more/additional", 72), "XLM-R": ("absorbed", 65), "mT5": ("middle/centre", 58)}),
         ("Ndre'", "understand/comprehend", {"mBERT": ("see/notice", 68), "XLM-R": ("understand/comprehend", 62), "mT5": ("understand/comprehend", 59)}),
         ("Fé", "cause/make happen", {"mBERT": ("give/provide", 75), "XLM-R": ("allow/permit", 71), "mT5": ("give/provide", 67)})]
fig, axes = plt.subplots(3, 1, figsize=(4.4, 6.2), gridspec_kw={"height_ratios": [4, 3, 3]})
for ax, (w, gold, pred) in zip(axes, CASES):
    ss = SENSES[w]
    ax.set_xlim(-0.5, 2.5); ax.set_ylim(len(ss) - 0.5, -0.5)
    for i, (s, f) in enumerate(ss):
        for j, m in enumerate(MODELS):
            chosen = pred[m][0] == s
            fc = (fs.SERIES[0] if s == gold else fs.SERIES[1]) if chosen else "#f4f3ef"
            ax.add_patch(Rectangle((j - 0.45, i - 0.42), 0.9, 0.84, fc=fc, ec="white", lw=1.5))
            if chosen:
                ax.text(j, i, ("✓ " if s == gold else "✗ ") + f"{pred[m][1]}%", ha="center", va="center", fontsize=7.2, color="white")
    ax.set_xticks(range(3)); ax.set_xticklabels(MODELS, fontsize=7.5)
    ax.xaxis.tick_top()
    ax.set_yticks(range(len(ss)))
    ax.set_yticklabels([f"{s} ({f}%)" for s, f in ss], fontsize=7.2)
    for lab, (s, _) in zip(ax.get_yticklabels(), ss):
        if s == gold: lab.set_fontweight("bold"); lab.set_color(fs.INK)
    ax.set_title(f"{['Case 1', 'Case 2', 'Case 3'][[c[0] for c in CASES].index(w)]}: {w}", loc="left", fontsize=9, style="italic", pad=22)
    ax.grid(False); ax.tick_params(length=0)
    for sp in ax.spines.values(): sp.set_visible(False)
fig.tight_layout(h_pad=1.2)
save(fig, "ch4_sense_choice_matrix.png")
# did the wrong choices pick the majority sense?
wrong = [(w, m, pred[m][0]) for w, gold, pred in CASES for m in MODELS if pred[m][0] != gold]
A["case_wrong_choices"] = len(wrong)
A["case_wrong_majority"] = sum(1 for w, m, s in wrong if s == SENSES[w][0][0])

# ---------------- 4. outcome matrix over the eight probe sentences
SENT = ["Case 1: Áti'bo' aga'angu'ra", "Case 2: Áa' ndre' driá tálí", "Case 3: Ozo' fé ori'",
        "Ma' du' 'imba'ta'", "Í 'do' a'ku'", "Ázíní rí ókó", "Ba'wara a'i a'je ra", "'Diri azi nga mi'dri'"]
OUTC = {"mBERT": "x~x" + "x~xx~", "XLM-R": "x✓x" + "~~✓✓✓", "mT5": "x✓x" + "✓✓✓✓✓"}
OUTC = {m: [c.replace("✓", "c") for c in v] for m, v in OUTC.items()}
counts = {m: {"correct": v.count("c"), "partial": v.count("~"), "wrong": v.count("x")} for m, v in OUTC.items()}
A["outcome_counts"] = counts
col = {"c": fs.SERIES[0], "~": fs.SERIES[3], "x": fs.SERIES[1]}
sym = {"c": "✓", "~": "~", "x": "✗"}
fig, ax = plt.subplots(figsize=(5.4, 3.3))
for i, s in enumerate(SENT):
    for j, m in enumerate(MODELS):
        o = OUTC[m][i]
        ax.add_patch(Rectangle((j - 0.45, i - 0.42), 0.9, 0.84, fc=col[o], ec="white", lw=1.5))
        ax.text(j, i, sym[o], ha="center", va="center", fontsize=9, color="white" if o != "~" else fs.INK)
ax.set_xlim(-0.5, 2.5); ax.set_ylim(len(SENT) - 0.5, -0.5)
ax.set_xticks(range(3)); ax.set_xticklabels([f"{m}\n{counts[m]['correct']} ✓ / {counts[m]['partial']} ~ / {counts[m]['wrong']} ✗" for m in MODELS], fontsize=7.2)
ax.set_yticks(range(len(SENT))); ax.set_yticklabels(SENT, fontsize=7, style="italic")
ax.grid(False); ax.tick_params(length=0)
for sp in ax.spines.values(): sp.set_visible(False)
ax.xaxis.tick_top()
save(fig, "ch4_outcome_matrix.png")

# ---------------- 5. confidence vs correctness (case studies)
pts = []
for (w, gold, pred), case in zip(CASES, ["Case 1", "Case 2", "Case 3"]):
    for m in MODELS:
        s, c = pred[m]
        o = "correct" if s == gold else ("partial" if (case == "Case 2" and m == "mBERT") else "wrong")
        pts.append((case, m, c, o))
A["confidence_points"] = pts
by = {o: [c for _, _, c, oo in pts if oo == o] for o in ["correct", "partial", "wrong"]}
A["confidence_mean"] = {o: (round(float(np.mean(v)), 1) if v else None) for o, v in by.items()}
conf = {(case, m): c for case, m, c, _o in pts}
A["confidence_order_each_case"] = all(
    conf[(case, "mBERT")] > conf[(case, "XLM-R")] > conf[(case, "mT5")] for case in ["Case 1", "Case 2", "Case 3"])
fig, ax = plt.subplots(figsize=(5.6, 2.3))
ymap = {"mBERT": 2, "XLM-R": 1, "mT5": 0}
mk = {"Case 1": "o", "Case 2": "s", "Case 3": "D"}
for case, m, c, o in pts:
    ax.scatter([c], [ymap[m] + {"Case 1": 0.15, "Case 2": 0, "Case 3": -0.15}[case]], s=46, marker=mk[case],
               color={"correct": fs.SERIES[0], "partial": fs.SERIES[3], "wrong": fs.SERIES[1]}[o], edgecolor="white", linewidth=1.2, zorder=3)
ax.set_yticks([0, 1, 2]); ax.set_yticklabels(["mT5", "XLM-R", "mBERT"])
ax.set_xlabel("Recorded confidence of the predicted sense (%)"); ax.set_xlim(54, 79)
ax.grid(axis="y", visible=False)
from matplotlib.lines import Line2D
h = [Line2D([], [], marker="o", ls="", color=fs.SERIES[0], label="Correct"), Line2D([], [], marker="o", ls="", color=fs.SERIES[3], label="Partially correct"),
     Line2D([], [], marker="o", ls="", color=fs.SERIES[1], label="Wrong"),
     Line2D([], [], marker="o", ls="", color=fs.MUTED, label="Case 1"), Line2D([], [], marker="s", ls="", color=fs.MUTED, label="Case 2"),
     Line2D([], [], marker="D", ls="", color=fs.MUTED, label="Case 3")]
ax.legend(handles=h, ncol=6, loc="lower center", bbox_to_anchor=(0.5, 1.0), fontsize=6.6, handletextpad=0.2, columnspacing=0.8)
save(fig, "ch4_confidence_correctness.png")

# ---------------- 6. agreement between automatic metrics (system level)
SYS = [("mBERT", "en", 12.34, 68.91, 0.62), ("XLM-R", "en", 15.67, 63.45, 0.67), ("mT5", "en", 18.92, 59.83, 0.71),
       ("ULMFiT", "en", 10.15, 72.30, 0.58), ("XLM-R (tuned)", "en", 22.18, 55.12, 0.76),
       ("mBERT", "lg", 14.57, 65.23, 0.65), ("XLM-R", "lg", 18.92, 60.10, 0.70), ("mT5", "lg", 21.05, 56.89, 0.74),
       ("ULMFiT", "lg", 11.89, 70.45, 0.61), ("mT5 (tuned)", "lg", 25.41, 52.67, 0.79)]
b = np.array([s[2] for s in SYS]); t = np.array([s[3] for s in SYS]); f = np.array([s[4] for s in SYS])
A["pearson"] = {"BLEU_TER": round(float(stats.pearsonr(b, t)[0]), 3), "BLEU_F1": round(float(stats.pearsonr(b, f)[0]), 3), "TER_F1": round(float(stats.pearsonr(t, f)[0]), 3)}
A["pearson_p"] = {"BLEU_TER": float(stats.pearsonr(b, t)[1]), "BLEU_F1": float(stats.pearsonr(b, f)[1])}
A["slope"] = {"TER_per_BLEU": round(float(np.polyfit(b, t, 1)[0]), 3), "F1_per_BLEU": round(float(np.polyfit(b, f, 1)[0]), 4)}
fig, axes = plt.subplots(1, 2, figsize=(6.6, 2.7))
for ax, y, lab, key in [(axes[0], t, "TER", "BLEU_TER"), (axes[1], f, "F1-score", "BLEU_F1")]:
    for d, ci, nm in [("en", 0, "English → Lugbara"), ("lg", 1, "Lugbara → English")]:
        idx = [i for i, s in enumerate(SYS) if s[1] == d]
        ax.scatter(b[idx], y[idx], s=36, color=fs.SERIES[ci], edgecolor="white", linewidth=1.2, zorder=3, label=nm)
    p = np.polyfit(b, y, 1); xs = np.linspace(9, 27, 10)
    ax.plot(xs, np.polyval(p, xs), color=fs.AXIS, lw=1.2, zorder=1)
    ax.text(0.97, 0.06 if key == "BLEU_F1" else 0.93, f"r = {A['pearson'][key]:.3f}", transform=ax.transAxes, ha="right", va="bottom" if key == "BLEU_F1" else "top", fontsize=8, color=fs.INK2)
    ax.set_xlabel("BLEU"); ax.set_ylabel(lab)
h, l = axes[0].get_legend_handles_labels()
fig.legend(h, l, ncol=2, loc="lower center", bbox_to_anchor=(0.5, -0.03))
fig.tight_layout(rect=(0, 0.07, 1, 1))
save(fig, "ch4_metric_agreement.png")

# ---------------- 7. direction asymmetry details
DIR = {}
for m in ["mBERT", "XLM-R", "mT5", "ULMFiT"]:
    e = [s for s in SYS if s[0] == m and s[1] == "en"][0]; g = [s for s in SYS if s[0] == m and s[1] == "lg"][0]
    DIR[m] = {"bleu_en": e[2], "bleu_lg": g[2], "gap": round(g[2] - e[2], 2), "ratio": round(e[2] / g[2], 3),
              "rel_gap_pct": round((g[2] - e[2]) / g[2] * 100, 1), "ter_gap": round(e[3] - g[3], 2), "f1_gap": round(g[4] - e[4], 2)}
A["direction"] = DIR
A["direction_mean_gap"] = round(float(np.mean([v["gap"] for v in DIR.values()])), 2)

# ---------------- 8. relative changes from tuning, and ranking
A["tuning"] = {"XLM-R en": {"bleu_abs": 6.51, "bleu_rel": round(6.51 / 15.67 * 100, 1), "ter_abs": -8.33, "ter_rel": round(-8.33 / 63.45 * 100, 1),
                            "f1_abs": 0.09, "f1_rel": round(0.09 / 0.67 * 100, 1)},
               "mT5 lg": {"bleu_abs": 4.36, "bleu_rel": round(4.36 / 21.05 * 100, 1), "ter_abs": -4.22, "ter_rel": round(-4.22 / 56.89 * 100, 1),
                          "f1_abs": 0.05, "f1_rel": round(0.05 / 0.74 * 100, 1)}}
base = ["mBERT", "XLM-R", "mT5", "ULMFiT"]
ranks = {}
for d in ["en", "lg"]:
    for mi, mname, hb in [(2, "BLEU", True), (3, "TER", False), (4, "F1", True)]:
        vals = [[s for s in SYS if s[0] == m and s[1] == d][0][mi] for m in base]
        order = stats.rankdata([-v if hb else v for v in vals], method="min")
        ranks[f"{mname}-{d}"] = dict(zip(base, [int(x) for x in order]))
A["ranks"] = ranks
Rm = np.array([[ranks[k][m] for m in base] for k in ranks])
k, n = Rm.shape; S = ((Rm.sum(0) - k * (n + 1) / 2) ** 2).sum()
A["kendall_W_models"] = round(float(12 * S / (k ** 2 * (n ** 3 - n))), 3)
# gain of best baseline over weakest
A["mt5_over_ulmfit"] = {"en": round(18.92 - 10.15, 2), "lg": round(21.05 - 11.89, 2)}
A["xlmr_over_mbert"] = {"en": round(15.67 - 12.34, 2), "lg": round(18.92 - 14.57, 2)}

# ---------------- 9. domain deviation
A["domain_dev"] = {"Tourism": round(24.5 - 21.2, 1), "Agriculture": round(22.8 - 21.2, 1), "Religion": round(19.7 - 21.2, 1)}
A["domain_rel_spread_pct"] = round((24.5 - 19.7) / 19.7 * 100, 1)

# ---------------- 10. error Pareto
ERR = [("Morphological", 45), ("Lexical omission", 25), ("Word order", 15), ("Semantic", 10), ("Other", 5)]
cum = np.cumsum([v for _, v in ERR])
A["error_cumulative"] = dict(zip([e for e, _ in ERR], [int(c) for c in cum]))
fig, ax = plt.subplots(figsize=(5.6, 2.6))
xs = np.arange(len(ERR))
bars = ax.bar(xs, [v for _, v in ERR], width=0.5, color=fs.SERIES[0], zorder=2, label="Share of errors")
fs.value_labels(ax, bars, fmt="{:.0f}%", size=7.5)
ax.plot(xs, cum, color=fs.SERIES[1], marker="o", ms=5, zorder=3, label="Cumulative share")
for x, c in list(zip(xs, cum))[1:]:
    ax.annotate(f"{c}%", (x, c), xytext=(0, 6), textcoords="offset points", ha="center", fontsize=7, color=fs.INK2)
ax.set_xticks(xs); ax.set_xticklabels([e.replace(" ", "\n", 1) if e == "Lexical omission" else e for e, _ in ERR])
ax.set_ylim(0, 112); ax.set_ylabel("Share of annotated errors (%)")
ax.grid(axis="x", visible=False); ax.legend(loc="center right", fontsize=7.5)
save(fig, "ch4_error_pareto.png")

json.dump(A, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "analysis.json"), "w"), indent=1, ensure_ascii=False)
print(json.dumps({k: A[k] for k in ["majority_mean", "lift_mean", "lift_below_or_at_zero", "entropy", "spearman_entropy_acc", "spearman_majority_acc",
                                    "kendall_W_word_difficulty", "case_wrong_choices", "case_wrong_majority", "outcome_counts", "confidence_mean",
                                    "pearson", "slope", "direction", "direction_mean_gap", "tuning", "kendall_W_models", "domain_dev",
                                    "domain_rel_spread_pct", "error_cumulative", "mt5_over_ulmfit", "xlmr_over_mbert"]}, indent=0, ensure_ascii=False))
