"""Shared figure style for all thesis plots (print-oriented, white surface)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager

SURFACE = "#ffffff"
INK = "#0b0b0b"
INK2 = "#52514e"
MUTED = "#898781"
GRID = "#e1e0d9"
AXIS = "#c3c2b7"
DEEMPH = "#c3c2b7"   # de-emphasis gray for non-focal bars

# Categorical slots in fixed order (validated on white: adjacent CVD dE >= 9.1)
SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
# Sequential blue ramp (light -> dark)
SEQ_BLUE = ["#cde2fb", "#b7d3f6", "#9ec5f4", "#86b6ef", "#6da7ec", "#5598e7",
            "#3987e5", "#2a78d6", "#256abf", "#1c5cab", "#184f95", "#104281", "#0d366b"]

_fams = {f.name for f in font_manager.fontManager.ttflist}
FONT = "Inter" if "Inter" in _fams else "DejaVu Sans"


def apply():
    plt.rcParams.update({
        "font.family": FONT,
        "font.size": 9,
        "axes.facecolor": SURFACE,
        "figure.facecolor": SURFACE,
        "savefig.facecolor": SURFACE,
        "axes.edgecolor": AXIS,
        "axes.linewidth": 0.8,
        "axes.labelcolor": INK2,
        "axes.titlesize": 10,
        "axes.titleweight": "semibold",
        "axes.titlecolor": INK,
        "axes.titlelocation": "left",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "axes.axisbelow": True,
        "grid.color": GRID,
        "grid.linewidth": 0.6,
        "grid.linestyle": "-",
        "xtick.color": MUTED,
        "ytick.color": MUTED,
        "xtick.labelcolor": INK2,
        "ytick.labelcolor": INK2,
        "xtick.major.size": 0,
        "ytick.major.size": 0,
        "legend.frameon": False,
        "legend.fontsize": 8.5,
        "lines.linewidth": 2,
        "lines.solid_capstyle": "round",
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.08,
    })


def value_labels(ax, bars, fmt="{:.1f}", inside=False, size=7.5, pad=2):
    """Put the value at the tip of each bar in text ink (never the series colour)."""
    for b in bars:
        h = b.get_height() if b.get_height() is not None else 0
        if h != h:  # NaN
            continue
        x = b.get_x() + b.get_width() / 2
        ax.annotate(fmt.format(h), (x, h), xytext=(0, pad), textcoords="offset points",
                    ha="center", va="bottom", fontsize=size, color=INK2)


def hvalue_labels(ax, bars, fmt="{:.1f}", size=7.5, pad=3):
    for b in bars:
        w = b.get_width()
        if w != w:
            continue
        y = b.get_y() + b.get_height() / 2
        ax.annotate(fmt.format(w), (w, y), xytext=(pad, 0), textcoords="offset points",
                    ha="left", va="center", fontsize=size, color=INK2)
