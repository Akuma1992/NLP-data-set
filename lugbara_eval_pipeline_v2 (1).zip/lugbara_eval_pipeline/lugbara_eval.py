#!/usr/bin/env python3
"""
lugbara_eval.py - evaluation pipeline for "An Optimized Machine Translation Model
for Low-Resource Lugbara Language".

Implements the evaluation framework of Chapter 3 (Section 3.5 / 3.7):
  BLEU, TER (sacreBLEU), METEOR (NLTK), Exact Sense Match (ESM),
  Apostrophe Integrity Rate (AIR), 95% bootstrap confidence intervals and
  paired bootstrap significance tests (1,000 resamples), overall and per domain.

Usage:
    python lugbara_eval.py --manifest manifest.json --out results/

See manifest.example.json for the input format. Every output (CSV, JSON,
PNG, summary.md) is computed from the files listed in the manifest only.
"""
import argparse
import json
import math
import os
import re
import sys
from collections import Counter, defaultdict

import numpy as np
import pandas as pd
from sacrebleu.metrics import BLEU, TER

GLOTTAL_VARIANTS = {"’": "'", "‘": "'", "ʼ": "'", "`": "'", "´": "'"}
DIR_TAG = re.compile(r"^\s*<2(en|lg)>\s*")
DIRECTIONS = ["en2lg", "lg2en"]
DIR_LABEL = {"en2lg": "English→Lugbara", "lg2en": "Lugbara→English"}


# --------------------------------------------------------------------------- io
def norm_text(s, glottal=True, lower=True):
    s = "" if s is None or (isinstance(s, float) and math.isnan(s)) else str(s)
    s = DIR_TAG.sub("", s)
    if glottal:
        for k, v in GLOTTAL_VARIANTS.items():
            s = s.replace(k, v)
    s = re.sub(r"\s+", " ", s).strip()
    return s.lower() if lower else s


def read_lines(path, expected=None, **kw):
    with open(path, encoding="utf-8") as f:
        lines = [norm_text(l.rstrip("\n"), **kw) for l in f]
    # tolerate one trailing empty line
    if expected is not None and len(lines) == expected + 1 and lines[-1] == "":
        lines = lines[:-1]
    if expected is not None and len(lines) != expected:
        raise ValueError(f"{path}: {len(lines)} lines, expected {expected} (outputs must align 1:1 with the test set)")
    return lines


def resolve(base, p):
    return p if os.path.isabs(p) else os.path.join(base, p)


# --------------------------------------------------------------------- metrics
_BLEU = BLEU()
_TER = TER()


def bleu_stats(hyps, refs):
    return np.asarray(_BLEU._extract_corpus_statistics(hyps, [refs]), dtype=float)


def bleu_from_stats(s):
    return _BLEU._compute_score_from_stats(list(s)).score


def ter_stats(hyps, refs):
    return np.asarray(_TER._extract_corpus_statistics(hyps, [refs]), dtype=float)


def ter_from_stats(s):
    return _TER._compute_score_from_stats(list(s)).score


class _NoWordNet:
    """Disables METEOR's synonym module (no Lugbara WordNet exists)."""
    @staticmethod
    def synsets(*a, **k):
        return []


class _IdentityStemmer:
    @staticmethod
    def stem(w):
        return w


def meteor_sentences(hyps, refs, target_lang):
    from nltk.translate.meteor_score import meteor_score
    out = np.zeros(len(hyps))
    for i, (h, r) in enumerate(zip(hyps, refs)):
        ht, rt = h.split(), r.split()
        if not ht or not rt:
            out[i] = 0.0
            continue
        if target_lang == "en":
            out[i] = meteor_score([rt], ht)
        else:  # exact-match METEOR for Lugbara output
            out[i] = meteor_score([rt], ht, stemmer=_IdentityStemmer(), wordnet=_NoWordNet())
    return out * 100.0


# ---------------------------------------------------------------- bootstrap
def boot_indices(n, B, seed):
    rng = np.random.default_rng(seed)
    return rng.integers(0, n, size=(B, n))


def corpus_metric_samples(kind, per_sent, idx):
    """Return B resampled corpus-level scores for one system."""
    if kind == "BLEU":
        return np.array([bleu_from_stats(per_sent[i].sum(0)) for i in idx])
    if kind == "TER":
        return np.array([ter_from_stats(per_sent[i].sum(0)) for i in idx])
    # sentence-average metrics (METEOR, ESM)
    return per_sent[idx].mean(1)


def corpus_metric_point(kind, per_sent):
    if kind == "BLEU":
        return bleu_from_stats(per_sent.sum(0))
    if kind == "TER":
        return ter_from_stats(per_sent.sum(0))
    return float(np.mean(per_sent))


HIGHER_BETTER = {"BLEU": True, "TER": False, "METEOR": True, "ESM": True, "AIR": True}


def paired_test(kind, ps1, ps2, idx):
    """Paired bootstrap (Koehn, 2004). Returns observed improvement of system 2
    over system 1 (positive = better), its 95% CI and a two-sided p-value."""
    s1 = corpus_metric_samples(kind, ps1, idx)
    s2 = corpus_metric_samples(kind, ps2, idx)
    sign = 1.0 if HIGHER_BETTER[kind] else -1.0
    d = sign * (s2 - s1)
    obs = sign * (corpus_metric_point(kind, ps2) - corpus_metric_point(kind, ps1))
    B = len(d)
    p_le = (np.sum(d <= 0) + 1) / (B + 1)
    p_ge = (np.sum(d >= 0) + 1) / (B + 1)
    p = min(1.0, 2 * min(p_le, p_ge))
    lo, hi = np.percentile(d, [2.5, 97.5])
    return obs, lo, hi, p


# ---------------------------------------------------------------------- ESM
EN_IRREG = {}


def en_variants(phrase):
    """Simple English inflection so lexicon glosses match inflected output."""
    words = phrase.split()
    if len(words) != 1:
        return {phrase}
    w = words[0]
    v = {w, w + "s", w + "es", w + "ed", w + "d", w + "ing"}
    if w.endswith("e"):
        v |= {w[:-1] + "ing"}
    if w.endswith("y") and len(w) > 2 and w[-2] not in "aeiou":
        v |= {w[:-1] + "ies", w[:-1] + "ied"}
    if len(w) >= 3 and w[-1] not in "aeiouwxy" and w[-2] in "aeiou" and w[-3] not in "aeiou":
        v |= {w + w[-1] + "ed", w + w[-1] + "ing"}
    v |= set(EN_IRREG.get(w, []))
    return v


def compile_renderings(cell, lang):
    pats = []
    for r in [x.strip() for x in str(cell or "").split("|") if x.strip()]:
        if r.startswith("re:"):
            pats.append(re.compile(r[3:]))
            continue
        r = norm_text(r)
        forms = en_variants(r) if lang == "en" else {r}
        alt = "|".join(sorted((re.escape(f) for f in forms), key=len, reverse=True))
        pats.append(re.compile(r"(?<![\w'])(?:" + alt + r")(?![\w'])"))
    return pats


def load_lexicon(path):
    lex = pd.read_csv(path)
    req = {"word", "sense_id"}
    if not req.issubset(lex.columns):
        raise ValueError(f"lexicon needs columns {req}; has {list(lex.columns)}")
    senses = defaultdict(dict)
    for _, r in lex.iterrows():
        w = norm_text(r["word"])
        senses[w][str(r["sense_id"])] = {
            "en": compile_renderings(r.get("english_renderings", ""), "en"),
            "lg": compile_renderings(r.get("lugbara_renderings", ""), "lg"),
            "freq": float(r["frequency"]) if "frequency" in lex.columns and pd.notna(r.get("frequency")) else np.nan,
            "gloss": r.get("gloss", ""),
        }
    return senses


def classify_sense(output, word, gold, senses, target_lang):
    inv = senses.get(norm_text(word))
    if not inv or str(gold) not in inv:
        return "unresolved", []
    matched = {}
    for sid, d in inv.items():
        hits = set()
        for p in d[target_lang]:
            for m in p.finditer(output):
                hits.add(m.group(0))
        if hits:
            matched[sid] = hits
    gold = str(gold)
    if not matched:
        return "unresolved", []
    others = [s for s, h in matched.items() if s != gold and not (gold in matched and h <= matched[gold])]
    if gold in matched and not others:
        return "correct", list(matched)
    if gold in matched:
        return "ambiguous", list(matched)
    return "wrong", list(matched)


# ---------------------------------------------------------------------- AIR
GLOTTAL_TOKEN = re.compile(r"(?<!\S)'[^\s']\S*")


def air_output_level(hyps, refs):
    """Per-sentence (preserved, broken) counts for glottal-initial reference tokens."""
    pres = np.zeros(len(hyps))
    brok = np.zeros(len(hyps))
    for i, (h, r) in enumerate(zip(hyps, refs)):
        htoks = Counter(h.split())
        hstripped = Counter(t.lstrip("'") for t in h.split() if not t.startswith("'"))
        hsplit = h.replace("' ", "'")  # "' bá" -> "'bá" signals a split token
        for t in GLOTTAL_TOKEN.findall(r):
            t = t.strip(".,;:!?\"()")
            if htoks.get(t, 0) > 0:
                pres[i] += 1
            elif hstripped.get(t[1:], 0) > 0 or (" ' " + t[1:]) in (" " + h + " ") or t in hsplit.split():
                brok[i] += 1
    return pres, brok


def air_tokenizer_level(words, tokenizer_path, placeholder=None):
    from transformers import AutoTokenizer  # optional dependency
    tok = AutoTokenizer.from_pretrained(tokenizer_path)
    ok = 0
    for w in words:
        src = w.replace("'", placeholder) if placeholder else w
        ids = tok(src, add_special_tokens=False)["input_ids"]
        pieces = tok.convert_ids_to_tokens(ids)
        dec = tok.decode(ids, skip_special_tokens=True).strip()
        if placeholder:
            dec = dec.replace(placeholder, "'")
        first = pieces[0].lstrip("▁Ġ#") if pieces else ""
        glott = placeholder or "'"
        isolated = first in ("", glott)
        if dec == w and not isolated and tok.unk_token not in pieces:
            ok += 1
    return 100.0 * ok / max(1, len(words))


# ----------------------------------------------------------------- main eval
def evaluate(manifest_path, out_dir):
    base = os.path.dirname(os.path.abspath(manifest_path))
    M = json.load(open(manifest_path, encoding="utf-8"))
    os.makedirs(out_dir, exist_ok=True)
    B = int(M.get("bootstrap", {}).get("n", 1000))
    seed = int(M.get("bootstrap", {}).get("seed", 12345))
    glottal = bool(M.get("normalize_glottal", True))
    lower = bool(M.get("lowercase", True))
    kw = dict(glottal=glottal, lower=lower)

    cols = {"id": "id", "domain": "domain", "en": "english", "lg": "lugbara"}
    cols.update(M.get("columns", {}))
    test = pd.read_csv(resolve(base, M["test_csv"]))
    n = len(test)
    refs = {"en2lg": [norm_text(x, **kw) for x in test[cols["lg"]]],
            "lg2en": [norm_text(x, **kw) for x in test[cols["en"]]]}
    domains = test[cols["domain"]].astype(str).str.strip().str.title().tolist() if cols["domain"] in test else ["All"] * n
    idx_all = boot_indices(n, B, seed)

    systems = M["systems"]
    order = list(systems.keys())
    per = {}          # per[(sys, dir)] = dict(metric -> per-sentence array)
    rows = []
    for s in order:
        for d in DIRECTIONS:
            p = systems[s].get(d)
            if not p:
                continue
            hyps = read_lines(resolve(base, p), n, **kw)
            tl = "lg" if d == "en2lg" else "en"
            ps = {"BLEU": bleu_stats(hyps, refs[d]), "TER": ter_stats(hyps, refs[d]),
                  "METEOR": meteor_sentences(hyps, refs[d], tl), "_hyps": hyps}
            if d == "en2lg":
                pr, br = air_output_level(hyps, refs[d])
                ps["_air"] = (pr, br)
            per[(s, d)] = ps
            row = {"system": s, "label": systems[s].get("label", s), "direction": d, "n": n}
            for k in ["BLEU", "TER", "METEOR"]:
                row[k] = corpus_metric_point(k, ps[k])
                smp = corpus_metric_samples(k, ps[k], idx_all)
                row[k + "_lo"], row[k + "_hi"] = np.percentile(smp, [2.5, 97.5])
            if d == "en2lg":
                pr, br = ps["_air"]
                tot = pr.sum() + br.sum()
                row["AIR_output"] = 100 * pr.sum() / tot if tot else np.nan
                row["AIR_tokens"] = int(tot)
            rows.append(row)
            print(f"  scored {s:>14} {d}: BLEU {row['BLEU']:.2f}  TER {row['TER']:.2f}  METEOR {row['METEOR']:.2f}")
    overall = pd.DataFrame(rows)

    # tokenizer-level AIR (optional)
    air_cfg = M.get("air", {})
    if air_cfg.get("tokenizers"):
        words = sorted({t.strip(".,;:!?\"()") for r in refs["en2lg"] for t in GLOTTAL_TOKEN.findall(r)})
        for s, tp in air_cfg["tokenizers"].items():
            v = air_tokenizer_level(words, resolve(base, tp), air_cfg.get("placeholder"))
            overall.loc[overall.system == s, "AIR_tokenizer"] = v
        overall["AIR_words"] = len(words)

    # per-domain
    drows = []
    dom_arr = np.array(domains)
    for (s, d), ps in per.items():
        for dom in sorted(set(domains)):
            m = np.where(dom_arr == dom)[0]
            idx = boot_indices(len(m), B, seed)
            r = {"system": s, "direction": d, "domain": dom, "n": len(m)}
            for k in ["BLEU", "TER", "METEOR"]:
                sub = ps[k][m]
                r[k] = corpus_metric_point(k, sub)
                r[k + "_lo"], r[k + "_hi"] = np.percentile(corpus_metric_samples(k, sub, idx), [2.5, 97.5])
            if d == "en2lg":
                pr, br = ps["_air"]
                tot = pr[m].sum() + br[m].sum()
                r["AIR_output"] = 100 * pr[m].sum() / tot if tot else np.nan
            drows.append(r)
    by_domain = pd.DataFrame(drows)

    # ESM on the polysemy test set
    esm_rows, esm_detail = [], []
    esm_per = {}
    P = M.get("polysemy")
    if P:
        senses = load_lexicon(resolve(base, P["lexicon_csv"]))
        pt = pd.read_csv(resolve(base, P["test_csv"]))
        pt["direction"] = pt["direction"].str.strip().str.lower().str.replace("->", "2").str.replace("-", "2")
        manual = {}
        if P.get("manual_labels_csv"):
            ml = pd.read_csv(resolve(base, P["manual_labels_csv"]))
            for _, r in ml.iterrows():
                manual[(str(r["id"]), r["system"], r["direction"])] = str(r["predicted_sense"])
        for s, spec in P["outputs"].items():
            for d in DIRECTIONS:
                sub = pt[pt.direction == d].reset_index(drop=True)
                if spec.get("file"):
                    allo = read_lines(resolve(base, spec["file"]), len(pt), **kw)
                    outs = [allo[i] for i in pt.index[pt.direction == d]]
                elif spec.get(d):
                    outs = read_lines(resolve(base, spec[d]), len(sub), **kw)
                else:
                    continue
                if not len(sub):
                    continue
                tl = "lg" if d == "en2lg" else "en"
                status = []
                for i, r in sub.iterrows():
                    key = (str(r["id"]), s, d)
                    if key in manual:
                        st = "correct" if manual[key] == str(r["gold_sense"]) else "wrong"
                        how = "manual"
                    else:
                        st, _ = classify_sense(outs[i], r["target_word"], r["gold_sense"], senses, tl)
                        how = "lexicon"
                    status.append(st)
                    inv = senses.get(norm_text(r["target_word"]), {})
                    freqs = sorted([v["freq"] for v in inv.values()], reverse=True)
                    gf = inv.get(str(r["gold_sense"]), {}).get("freq", np.nan)
                    rank = (freqs.index(gf) + 1) if (freqs and gf == gf and gf in freqs) else np.nan
                    esm_detail.append({"id": r["id"], "system": s, "direction": d, "target_word": r["target_word"],
                                       "gold_sense": r["gold_sense"], "sense_rank": rank, "status": st, "how": how,
                                       "output": outs[i]})
                corr = np.array([1.0 if x == "correct" else 0.0 for x in status])
                esm_per[(s, d)] = corr
                idx = boot_indices(len(corr), B, seed)
                c = Counter(status)
                lo, hi = np.percentile(corr[idx].mean(1), [2.5, 97.5])
                esm_rows.append({"system": s, "direction": d, "n": len(corr), "ESM": 100 * corr.mean(),
                                 "ESM_lo": 100 * lo, "ESM_hi": 100 * hi,
                                 "ESM_lenient": 100 * (c["correct"] + c["ambiguous"]) / len(corr),
                                 "correct": c["correct"], "ambiguous": c["ambiguous"], "wrong": c["wrong"],
                                 "unresolved": c["unresolved"]})
        esm = pd.DataFrame(esm_rows)
        if len(esm):
            overall = overall.merge(esm[["system", "direction", "ESM", "ESM_lo", "ESM_hi", "ESM_lenient", "unresolved"]],
                                    on=["system", "direction"], how="left")
        pd.DataFrame(esm_detail).to_csv(os.path.join(out_dir, "esm_detail.csv"), index=False)
        esm.to_csv(os.path.join(out_dir, "esm_summary.csv"), index=False)

    # significance tests
    sig = []
    for a, b in M.get("comparisons", []):
        for d in DIRECTIONS:
            if (a, d) not in per or (b, d) not in per:
                continue
            for k in ["BLEU", "TER", "METEOR"]:
                obs, lo, hi, p = paired_test(k, per[(a, d)][k], per[(b, d)][k], idx_all)
                sig.append({"from": a, "to": b, "direction": d, "metric": k, "improvement": obs,
                            "ci_lo": lo, "ci_hi": hi, "p_value": p, "significant": p < 0.05})
            if d == "en2lg":
                pa, ba = per[(a, d)]["_air"]
                pb, bb = per[(b, d)]["_air"]
                obs, lo, hi, p = _air_paired(pa, ba, pb, bb, idx_all)
                sig.append({"from": a, "to": b, "direction": d, "metric": "AIR", "improvement": obs,
                            "ci_lo": lo, "ci_hi": hi, "p_value": p, "significant": p < 0.05})
            if (a, d) in esm_per and (b, d) in esm_per and len(esm_per[(a, d)]) == len(esm_per[(b, d)]):
                ea, eb = esm_per[(a, d)] * 100, esm_per[(b, d)] * 100
                idx = boot_indices(len(ea), B, seed)
                obs, lo, hi, p = paired_test("ESM", ea, eb, idx)
                sig.append({"from": a, "to": b, "direction": d, "metric": "ESM", "improvement": obs,
                            "ci_lo": lo, "ci_hi": hi, "p_value": p, "significant": p < 0.05})
    sig = pd.DataFrame(sig)

    # write
    overall.to_csv(os.path.join(out_dir, "metrics_overall.csv"), index=False)
    by_domain.to_csv(os.path.join(out_dir, "metrics_by_domain.csv"), index=False)
    sig.to_csv(os.path.join(out_dir, "significance.csv"), index=False)
    meta = {"sacrebleu_bleu_signature": str(_BLEU.get_signature()),
            "sacrebleu_ter_signature": str(_TER.get_signature()),
            "bootstrap_resamples": B, "seed": seed, "n_test": n,
            "glottal_normalisation": glottal, "lowercase": lower,
            "meteor": "NLTK meteor_score; exact+stem+WordNet for English output, exact-match only for Lugbara output",
            "domains": dict(Counter(domains))}
    json.dump(meta, open(os.path.join(out_dir, "meta.json"), "w"), indent=2)
    write_summary(out_dir, overall, by_domain, sig, meta, systems)
    print(f"\nwrote results to {out_dir}")
    return overall, by_domain, sig


def _air_paired(pa, ba, pb, bb, idx):
    def rate(p, b, i):
        tot = p[i].sum() + b[i].sum()
        return 100 * p[i].sum() / tot if tot else np.nan
    obs = rate(pb, bb, slice(None)) - rate(pa, ba, slice(None))
    d = np.array([rate(pb, bb, i) - rate(pa, ba, i) for i in idx])
    d = d[~np.isnan(d)]
    if not len(d):
        return obs, np.nan, np.nan, np.nan
    p = min(1.0, 2 * min((np.sum(d <= 0) + 1) / (len(d) + 1), (np.sum(d >= 0) + 1) / (len(d) + 1)))
    lo, hi = np.percentile(d, [2.5, 97.5])
    return obs, lo, hi, p


def write_summary(out_dir, overall, by_domain, sig, meta, systems):
    L = ["# Evaluation summary", "", f"Test sentences: {meta['n_test']} | bootstrap resamples: {meta['bootstrap_resamples']}",
         f"BLEU signature: `{meta['sacrebleu_bleu_signature']}`", f"TER signature: `{meta['sacrebleu_ter_signature']}`", ""]
    for d in DIRECTIONS:
        sub = overall[overall.direction == d]
        if not len(sub):
            continue
        L += [f"## {DIR_LABEL[d]}", "", "| System | BLEU | TER | METEOR | ESM | AIR |", "|---|---|---|---|---|---|"]
        for _, r in sub.iterrows():
            esm = f"{r['ESM']:.1f}" if "ESM" in r and pd.notna(r.get("ESM")) else "-"
            air = f"{r['AIR_output']:.1f}" if "AIR_output" in r and pd.notna(r.get("AIR_output")) else "-"
            L.append(f"| {r['label']} | {r['BLEU']:.2f} [{r['BLEU_lo']:.2f}, {r['BLEU_hi']:.2f}] | "
                     f"{r['TER']:.2f} | {r['METEOR']:.2f} | {esm} | {air} |")
        L.append("")
    if len(sig):
        L += ["## Paired bootstrap tests", "", "| Comparison | Direction | Metric | Improvement | 95% CI | p |", "|---|---|---|---|---|---|"]
        for _, r in sig.iterrows():
            L.append(f"| {r['from']} → {r['to']} | {r['direction']} | {r['metric']} | {r['improvement']:+.2f} | "
                     f"[{r['ci_lo']:+.2f}, {r['ci_hi']:+.2f}] | {r['p_value']:.3f}{' *' if r['significant'] else ''} |")
    open(os.path.join(out_dir, "summary.md"), "w").write("\n".join(L) + "\n")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--out", default="results")
    ap.add_argument("--no-plots", action="store_true")
    a = ap.parse_args()
    evaluate(a.manifest, a.out)
    if not a.no_plots:
        import lugbara_plots
        lugbara_plots.make_all(a.manifest, a.out)
