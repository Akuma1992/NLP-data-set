"""Figures for Chapter 4, generated only from the CSVs written by lugbara_eval.py
and the optional log files named in the manifest."""
import json
import math
import os

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import figstyle as fs

ARROW = "\u2192"
SHORT = {"en2lg": "En\u2192Lg", "lg2en": "Lg\u2192En"}
DIR_LABEL = {"en2lg": "English → Lugbara", "lg2en": "Lugbara → English"}
METRIC_LABEL = {"BLEU": "BLEU (↑)", "TER": "TER (↓)", "METEOR": "METEOR (↑)",
                "ESM": "Exact Sense Match, % (↑)", "AIR_output": "Apostrophe Integrity, % (↑)"}


def _load(out):
    o = pd.read_csv(os.path.join(out, "metrics_overall.csv"))
    d = pd.read_csv(os.path.join(out, "metrics_by_domain.csv"))
    s = pd.read_csv(os.path.join(out, "significance.csv")) if os.path.getsize(os.path.join(out, "significance.csv")) > 1 else pd.DataFrame()
    return o, d, s


def _save(fig, out, name):
    p = os.path.join(out, "figures")
    os.makedirs(p, exist_ok=True)
    fig.savefig(os.path.join(p, name))
    plt.close(fig)
    return os.path.join(p, name)


def _bar_w(nseries, slot=0.8):
    return min(slot / max(1, nseries), 0.26)


def conditions_figure(o, systems, conds, out, name="fig_conditions_metrics.png"):
    """Small multiples: one panel per metric, bars = conditions, groups = direction."""
    metrics = [m for m in ["BLEU", "TER", "METEOR", "ESM", "AIR_output"] if m in o.columns and o[o.system.isin(conds)][m].notna().any()]
    if not metrics:
        return None
    ncol = 3
    nrow = math.ceil((len(metrics) + 1) / ncol)
    fig, axes = plt.subplots(nrow, ncol, figsize=(6.6, 2.35 * nrow))
    axes = np.atleast_1d(axes).ravel()
    w = _bar_w(len(conds))
    handles = {}
    for ai, m in enumerate(metrics):
        ax = axes[ai]
        sub = o[o.system.isin(conds)]
        dirs = [d for d in ["en2lg", "lg2en"] if sub[sub.direction == d][m].notna().any()]
        top = 0
        for ci, c in enumerate(conds):
            for di, d in enumerate(dirs):
                r = o[(o.system == c) & (o.direction == d)]
                if not len(r) or pd.isna(r.iloc[0].get(m)):
                    continue
                r = r.iloc[0]
                x = di + (ci - (len(conds) - 1) / 2) * (w + 0.02)
                b = ax.bar([x], [r[m]], width=w, color=fs.SERIES[ci], zorder=2)
                handles[c] = b
                lo, hi = r.get(m + "_lo", np.nan), r.get(m + "_hi", np.nan)
                ytxt = r[m]
                if pd.notna(lo) and pd.notna(hi):
                    ax.plot([x, x], [lo, hi], color=fs.INK2, lw=0.8, zorder=3)
                    ytxt = max(ytxt, hi)
                ax.annotate(f"{r[m]:.1f}", (x, ytxt), xytext=(0, 2), textcoords="offset points",
                            ha="center", va="bottom", fontsize=6, color=fs.INK2)
                top = max(top, ytxt)
        ax.set_xticks(range(len(dirs)))
        ax.set_xticklabels([SHORT[d] for d in dirs])
        ax.set_xlim(-0.6, len(dirs) - 0.4)
        ax.set_ylim(0, top * 1.16 if top else 1)
        ax.set_title(METRIC_LABEL[m], fontsize=8.5)
        ax.grid(axis="x", visible=False)
    for ax in axes[len(metrics):]:
        ax.axis("off")
    axes[len(metrics)].legend([handles[c] for c in conds if c in handles],
                              [systems[c].get("label", c) for c in conds if c in handles],
                              loc="center left", title="System", title_fontsize=8.5)
    fig.tight_layout(w_pad=1.2, h_pad=1.4)
    return _save(fig, out, name)


def baselines_figure(o, systems, baseline_ids, tuned_ids, out, name="fig_baselines_bleu.png"):
    ids = [s for s in baseline_ids + tuned_ids if s in set(o.system)]
    if not ids:
        return None
    dirs = [d for d in ["en2lg", "lg2en"] if d in set(o.direction)]
    fig, axes = plt.subplots(1, len(dirs), figsize=(6.6, 0.36 * len(ids) + 0.9), sharex=True)
    axes = np.atleast_1d(axes)
    for ax, d in zip(axes, dirs):
        sub = o[(o.direction == d) & (o.system.isin(ids))].set_index("system").reindex(ids).dropna(subset=["BLEU"])
        y = np.arange(len(sub))[::-1]
        cols = [fs.SERIES[0] if s in tuned_ids else fs.DEEMPH for s in sub.index]
        bars = ax.barh(y, sub["BLEU"], height=0.6, color=cols, zorder=2)
        ax.errorbar(sub["BLEU"], y, xerr=[sub["BLEU"] - sub["BLEU_lo"], sub["BLEU_hi"] - sub["BLEU"]],
                    fmt="none", ecolor=fs.INK2, elinewidth=0.8, zorder=3)
        for yy, v, hi in zip(y, sub["BLEU"], sub["BLEU_hi"]):
            ax.annotate(f"{v:.2f}", (max(v, hi), yy), xytext=(4, 0), textcoords="offset points",
                        ha="left", va="center", fontsize=7, color=fs.INK2)
        ax.set_yticks(y)
        ax.set_yticklabels([systems[s].get("label", s) for s in sub.index])
        ax.set_title(DIR_LABEL[d])
        ax.set_xlabel("BLEU")
        ax.grid(axis="y", visible=False)
        ax.margins(x=0.15)
    fig.tight_layout()
    return _save(fig, out, name)


def domain_figure(dm, systems, conds, out, metric="BLEU", name="fig_domain_bleu.png"):
    sub = dm[dm.system.isin(conds)]
    if not len(sub):
        return None
    dirs = [d for d in ["en2lg", "lg2en"] if d in set(sub.direction)]
    doms = sorted(set(sub.domain))
    fig, axes = plt.subplots(1, len(dirs), figsize=(6.6, 2.6), sharey=True)
    axes = np.atleast_1d(axes)
    w = _bar_w(len(conds))
    for ax, d in zip(axes, dirs):
        for ci, c in enumerate(conds):
            r = sub[(sub.system == c) & (sub.direction == d)].set_index("domain").reindex(doms)
            xs = np.arange(len(doms)) + (ci - (len(conds) - 1) / 2) * (w + 0.02)
            bars = ax.bar(xs, r[metric], width=w, color=fs.SERIES[ci], label=systems[c].get("label", c), zorder=2)
            ax.errorbar(xs, r[metric], yerr=[r[metric] - r[metric + "_lo"], r[metric + "_hi"] - r[metric]],
                        fmt="none", ecolor=fs.INK2, elinewidth=0.8, zorder=3)
        ax.set_xticks(range(len(doms)))
        ax.set_xticklabels(doms)
        ax.set_title(DIR_LABEL[d])
        ax.grid(axis="x", visible=False)
    axes[0].set_ylabel(metric)
    h, l = axes[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=len(conds), bbox_to_anchor=(0.5, -0.06))
    fig.tight_layout(rect=(0, 0.06, 1, 1))
    return _save(fig, out, name)


def esm_by_rank_figure(out, systems, conds, name="fig_esm_by_sense_rank.png"):
    p = os.path.join(out, "esm_detail.csv")
    if not os.path.exists(p):
        return None
    e = pd.read_csv(p)
    e = e[e.system.isin(conds) & e.sense_rank.notna()]
    if not len(e):
        return None
    e["band"] = np.where(e.sense_rank == 1, "Most frequent sense", "Less frequent senses")
    e["ok"] = (e.status == "correct").astype(float) * 100
    dirs = [d for d in ["en2lg", "lg2en"] if d in set(e.direction)]
    bands = ["Most frequent sense", "Less frequent senses"]
    fig, axes = plt.subplots(1, len(dirs), figsize=(6.6, 2.6), sharey=True)
    axes = np.atleast_1d(axes)
    w = _bar_w(len(conds))
    for ax, d in zip(axes, dirs):
        for ci, c in enumerate(conds):
            g = e[(e.system == c) & (e.direction == d)].groupby("band")["ok"].agg(["mean", "count"]).reindex(bands)
            xs = np.arange(len(bands)) + (ci - (len(conds) - 1) / 2) * (w + 0.02)
            bars = ax.bar(xs, g["mean"], width=w, color=fs.SERIES[ci], label=systems[c].get("label", c), zorder=2)
            fs.value_labels(ax, bars, fmt="{:.0f}", size=6.5)
        ax.set_xticks(range(len(bands)))
        ax.set_xticklabels(bands)
        ax.set_title(DIR_LABEL[d])
        ax.grid(axis="x", visible=False)
        ax.set_ylim(0, 105)
    axes[0].set_ylabel("Exact Sense Match (%)")
    h, l = axes[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=len(conds), bbox_to_anchor=(0.5, -0.06))
    fig.tight_layout(rect=(0, 0.06, 1, 1))
    return _save(fig, out, name)


def forest_figure(sig, systems, out, name="fig_significance_forest.png"):
    if sig is None or not len(sig):
        return None
    metrics = [m for m in ["BLEU", "TER", "METEOR", "ESM", "AIR"] if m in set(sig.metric)]
    comps = list(dict.fromkeys(zip(sig["from"], sig["to"])))
    dirs = [d for d in ["en2lg", "lg2en"] if d in set(sig.direction)]
    fig, axes = plt.subplots(1, len(metrics), figsize=(6.6, 0.42 * len(comps) * len(dirs) + 1.0), sharey=True)
    axes = np.atleast_1d(axes)
    labels = []
    for d in dirs:
        for a, b in comps:
            labels.append(f"{a}→{b} ({'En→Lg' if d == 'en2lg' else 'Lg→En'})")
    y = np.arange(len(labels))[::-1]
    for ax, m in zip(axes, metrics):
        k = 0
        for d in dirs:
            for a, b in comps:
                r = sig[(sig["from"] == a) & (sig["to"] == b) & (sig.direction == d) & (sig.metric == m)]
                if len(r):
                    r = r.iloc[0]
                    col = fs.SERIES[0] if r["significant"] else fs.MUTED
                    ax.plot([r.ci_lo, r.ci_hi], [y[k], y[k]], color=col, lw=2, solid_capstyle="round", zorder=2)
                    ax.scatter([r.improvement], [y[k]], s=34, color=col, edgecolor="white", linewidth=1.5, zorder=3)
                k += 1
        ax.axvline(0, color=fs.AXIS, lw=0.9, zorder=1)
        ax.set_title(m, fontsize=8.5)
        ax.grid(axis="y", visible=False)
        ax.tick_params(axis="x", labelsize=7)
    axes[0].set_yticks(y)
    axes[0].set_yticklabels(labels, fontsize=7.5)
    fig.supxlabel("Improvement of second system over first (positive = better; TER sign flipped)", fontsize=7.5, color=fs.INK2)
    fig.tight_layout()
    return _save(fig, out, name)


def training_figure(states, out, name="fig_training_curves.png"):
    """states: {label: path to HF trainer_state.json}. Two panels, never dual-axis."""
    if not states:
        return None
    fig, axes = plt.subplots(1, 3, figsize=(6.6, 2.3))
    for i, (lab, p) in enumerate(states.items()):
        h = json.load(open(p))["log_history"]
        tr = [(x["step"], x["loss"]) for x in h if "loss" in x]
        ev = [(x["step"], x["eval_loss"]) for x in h if "eval_loss" in x]
        bl = [(x["step"], x["eval_bleu"]) for x in h if "eval_bleu" in x]
        c = fs.SERIES[i % 8]
        if tr:
            axes[0].plot(*zip(*tr), color=c, label=lab, lw=1.5)
        if ev:
            axes[1].plot(*zip(*ev), color=c, label=lab, lw=1.5)
        if bl:
            axes[2].plot(*zip(*bl), color=c, label=lab, lw=1.5)
    for ax, t in zip(axes, ["Training loss", "Validation loss", "Validation BLEU"]):
        ax.set_title(t, fontsize=8.5)
        ax.set_xlabel("Step", fontsize=7.5)
        ax.tick_params(labelsize=7)
    h, l = axes[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=min(4, len(l)), bbox_to_anchor=(0.5, -0.08), fontsize=7.5)
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    return _save(fig, out, name)


def grid_figure(grid_csv, out, name="fig_grid_search.png"):
    if not grid_csv or not os.path.exists(grid_csv):
        return None
    g = pd.read_csv(grid_csv)
    keys = list(g.groupby(["model", "direction"]).groups)
    fig, axes = plt.subplots(1, len(keys), figsize=(min(6.6, 1.9 * len(keys) + 0.6), 2.2))
    axes = np.atleast_1d(axes)
    from matplotlib.colors import LinearSegmentedColormap
    cmap = LinearSegmentedColormap.from_list("seqblue", fs.SEQ_BLUE)
    vmin, vmax = g.val_bleu.min(), g.val_bleu.max()
    for ax, k in zip(axes, keys):
        sub = g[(g.model == k[0]) & (g.direction == k[1])].pivot_table(index="lr", columns="batch_size", values="val_bleu")
        ax.imshow(sub.values, cmap=cmap, vmin=vmin, vmax=vmax, aspect="auto")
        for (i, j), v in np.ndenumerate(sub.values):
            ax.text(j, i, f"{v:.1f}", ha="center", va="center", fontsize=7,
                    color="white" if (v - vmin) / max(1e-9, vmax - vmin) > 0.55 else fs.INK)
        ax.set_xticks(range(sub.shape[1]))
        ax.set_xticklabels(sub.columns)
        ax.set_yticks(range(sub.shape[0]))
        ax.set_yticklabels([f"{x:g}" for x in sub.index])
        ax.set_title(f"{k[0]} ({'En→Lg' if k[1] == 'en2lg' else 'Lg→En'})", fontsize=8)
        ax.set_xlabel("Batch size", fontsize=7.5)
        ax.grid(False)
    axes[0].set_ylabel("Learning rate", fontsize=7.5)
    fig.tight_layout()
    return _save(fig, out, name)


def latency_figure(lat_csv, o, systems, out, name="fig_compute_tradeoff.png"):
    if not lat_csv or not os.path.exists(lat_csv):
        return None
    lat = pd.read_csv(lat_csv)
    dirs = [d for d in ["en2lg", "lg2en"] if d in set(o.direction)]
    fig, axes = plt.subplots(1, len(dirs), figsize=(6.6, 2.5), sharex=True)
    axes = np.atleast_1d(axes)
    for ax, d in zip(axes, dirs):
        for _, r in lat.iterrows():
            q = o[(o.system == r.system) & (o.direction == d)]
            if not len(q):
                continue
            x, yv = r.ms_per_sentence, q.iloc[0].BLEU
            ax.scatter([x], [yv], s=40, color=fs.SERIES[0], edgecolor="white", linewidth=1.5, zorder=3)
            ax.annotate(systems.get(r.system, {}).get("label", r.system), (x, yv), xytext=(5, 3),
                        textcoords="offset points", fontsize=7, color=fs.INK2)
        ax.set_title(DIR_LABEL[d])
        ax.set_xlabel("Latency (ms / sentence)")
        ax.margins(x=0.25, y=0.2)
    axes[0].set_ylabel("BLEU")
    fig.tight_layout()
    return _save(fig, out, name)


def make_all(manifest_path, out):
    fs.apply()
    base = os.path.dirname(os.path.abspath(manifest_path))
    M = json.load(open(manifest_path))
    systems = M["systems"]
    o, dm, sig = _load(out)
    F = M.get("figures", {})
    conds = [c for c in F.get("conditions", ["A", "B", "C", "C_fallback"]) if c in systems]
    made = [conditions_figure(o, systems, conds, out),
            baselines_figure(o, systems, F.get("baselines", []), F.get("tuned", []), out),
            domain_figure(dm, systems, [c for c in conds if c != "C_fallback"] or conds, out),
            esm_by_rank_figure(out, systems, conds),
            forest_figure(sig, systems, out)]
    ts = {k: os.path.join(base, v) for k, v in M.get("trainer_states", {}).items()}
    made.append(training_figure(ts, out))
    made.append(grid_figure(os.path.join(base, M["grid_csv"]) if M.get("grid_csv") else None, out))
    made.append(latency_figure(os.path.join(base, M["latency_csv"]) if M.get("latency_csv") else None, o, systems, out))
    for m in made:
        if m:
            print("  figure:", m)
