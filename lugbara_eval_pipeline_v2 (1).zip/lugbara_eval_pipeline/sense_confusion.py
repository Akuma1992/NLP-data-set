#!/usr/bin/env python3
"""
sense_confusion.py - confusion matrices and per-sense precision/recall/F1 for the
polysemy probes of the English-Lugbara thesis.

Input: a CSV with one row per (probe sentence, model):
    id, word, gold_sense, model, predicted_sense[, domain]
where gold_sense / predicted_sense are sense labels from the sense lexicon
(e.g. "conquer/defeat"). Optional: --lexicon sense_lexicon.csv (word, sense_id or
gloss, frequency) to order rows by corpus frequency and compute the
majority-sense baseline.

Outputs (in --out):
    confusion_<word>.png       one heatmap panel per model (rows = gold, cols = predicted)
    confusion_counts.csv       long-format counts
    per_sense_prf.csv          precision, recall, F1 and support per word/sense/model
    summary.csv                accuracy, macro-F1, majority-sense accuracy per word/model
Usage:
    python sense_confusion.py --pred probe_predictions.csv --out results/sense/
"""
import argparse
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figstyle as fs  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.colors import LinearSegmentedColormap  # noqa: E402


def prf(cm, labels):
    rows = []
    for i, lab in enumerate(labels):
        tp = cm[i, i]
        fp = cm[:, i].sum() - tp
        fn = cm[i, :].sum() - tp
        p = tp / (tp + fp) if tp + fp else np.nan
        r = tp / (tp + fn) if tp + fn else np.nan
        f = 2 * p * r / (p + r) if p == p and r == r and (p + r) else np.nan
        rows.append({"sense": lab, "precision": p, "recall": r, "f1": f, "support": int(cm[i, :].sum())})
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pred", required=True)
    ap.add_argument("--lexicon")
    ap.add_argument("--out", default="results/sense")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    fs.apply()
    df = pd.read_csv(a.pred)
    need = {"word", "gold_sense", "model", "predicted_sense"}
    if not need.issubset(df.columns):
        raise SystemExit(f"--pred needs columns {need}")
    for c in ["word", "gold_sense", "model", "predicted_sense"]:
        df[c] = df[c].astype(str).str.strip()
    freq = {}
    if a.lexicon:
        lx = pd.read_csv(a.lexicon)
        gcol = "gloss" if "gloss" in lx.columns else "sense_id"
        for _, r in lx.iterrows():
            freq.setdefault(str(r["word"]).strip(), {})[str(r[gcol]).strip()] = float(r.get("frequency", np.nan))
    models = list(dict.fromkeys(df.model))
    cmap = LinearSegmentedColormap.from_list("seq", fs.SEQ_BLUE)
    counts, prfs, summ = [], [], []
    for w, g in df.groupby("word", sort=False):
        labels = list(dict.fromkeys(list(g.gold_sense) + list(g.predicted_sense)))
        if w in freq:
            labels.sort(key=lambda s: -freq[w].get(s, -1))
        k = len(labels)
        fig, axes = plt.subplots(1, len(models), figsize=(min(6.6, 2.2 * len(models) + 1), 0.45 * k + 1.4), squeeze=False)
        for ax, m in zip(axes[0], models):
            gm = g[g.model == m]
            cm = np.zeros((k, k), dtype=int)
            for _, r in gm.iterrows():
                cm[labels.index(r.gold_sense), labels.index(r.predicted_sense)] += 1
            for i in range(k):
                for j in range(k):
                    if cm[i, j]:
                        counts.append({"word": w, "model": m, "gold": labels[i], "predicted": labels[j], "count": int(cm[i, j])})
            rowsum = cm.sum(1, keepdims=True)
            norm = np.divide(cm, rowsum, out=np.zeros_like(cm, dtype=float), where=rowsum > 0)
            ax.imshow(norm, cmap=cmap, vmin=0, vmax=1)
            for (i, j), v in np.ndenumerate(cm):
                if v:
                    ax.text(j, i, str(v), ha="center", va="center", fontsize=7, color="white" if norm[i, j] > 0.55 else fs.INK)
            ax.set_xticks(range(k)); ax.set_xticklabels(labels, rotation=45, ha="right", fontsize=6.5)
            ax.set_yticks(range(k)); ax.set_yticklabels(labels if ax is axes[0][0] else [], fontsize=6.5)
            ax.set_title(m, fontsize=8.5); ax.grid(False)
            acc = np.trace(cm) / cm.sum() if cm.sum() else np.nan
            rows = prf(cm, labels)
            for r in rows:
                r.update({"word": w, "model": m})
            prfs += rows
            maj = labels[0] if w in freq else max(labels, key=lambda s: (g.gold_sense == s).sum())
            maj_acc = (gm.gold_sense == maj).mean() if len(gm) else np.nan
            f1s = [r["f1"] for r in rows if r["support"] > 0 and r["f1"] == r["f1"]]
            summ.append({"word": w, "model": m, "n": int(cm.sum()), "accuracy": acc,
                         "macro_f1": float(np.mean(f1s)) if f1s else np.nan,
                         "majority_sense": maj, "majority_sense_accuracy": maj_acc,
                         "lift_over_majority": acc - maj_acc if acc == acc and maj_acc == maj_acc else np.nan})
        axes[0][0].set_ylabel("Gold sense", fontsize=7.5)
        fig.supxlabel("Predicted sense", fontsize=7.5, color=fs.INK2)
        fig.suptitle(w, fontsize=9, style="italic")
        fig.tight_layout()
        safe = "".join(ch if ch.isalnum() else "_" for ch in w)
        fig.savefig(os.path.join(a.out, f"confusion_{safe}.png"))
        plt.close(fig)
    pd.DataFrame(counts).to_csv(os.path.join(a.out, "confusion_counts.csv"), index=False)
    pd.DataFrame(prfs).to_csv(os.path.join(a.out, "per_sense_prf.csv"), index=False)
    pd.DataFrame(summ).to_csv(os.path.join(a.out, "summary.csv"), index=False)
    print(pd.DataFrame(summ).to_string(index=False))


if __name__ == "__main__":
    main()
